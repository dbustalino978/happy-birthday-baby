const message = `
Happy Birthday to the most special person in my life! 🥰🌍.

Wala ko kabalo asa magsugod… pero sige lang, Ill speak from the heart.💖. I hope nga ang pagka 17 nimo mas better kaysa 16. And may this year bring you peace, happiness, success, and more love than ever before. 
Take time to relax and enjoy your day. Kalimti na ang mga problema or mga tao nga nakapaluya nimo. Focus sa imong self, dreams, and happiness. Ayaw sugot nga ang negativity maka effect sa imong life, and thankyouu kaayu babyy for being part of my life thankyouu for handling the stupid me, the weird me, the overthinking me, and even the stubborn me 😂 sagdi ra at least love tika duh.
 Di gyud nako malimtan ang mga katawa, hilak, ug memories nga atong na-create these year💞, and honestly. Im super possessive with you (in a sweet way) kay dili nako gusto nga mashare ka sa uban 😅bleee i feel so blessed nga ikaw akong uyab :>. You are my world and Im so proud and thankful to call you BABY HAHAHA mag-ampo ko nga ang imong 17th birthday will be full of blessings, peace, and joy.
 
 May this new chapter bring growth, love, and unforgettable moments 💕 Bisag layo ko karon, know that Im celebrating with you in spirit.
 
 I love you so much and Im always here for you Happy Birthday, My Love! 🌹💌🎂
`;

const startBtn = document.getElementById("start-btn");
const typedText = document.getElementById("typed-text");
const bgMusic = document.getElementById("bg-music");

let i = 0;

function typeMessage() {
  if (i < message.length) {
    typedText.textContent += message.charAt(i);
    i++;
    setTimeout(typeMessage, 50);
  }
}

startBtn.addEventListener("click", () => {
  startBtn.style.display = "none";
  bgMusic.play().catch(err => {
    console.log("Autoplay blocked, user must interact with the page.");
  });
  typeMessage();
});
